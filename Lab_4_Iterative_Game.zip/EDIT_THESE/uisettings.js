// A few different UI text settings that you can change, if you'd like to
var uiSettings = {
    // Main Menu text
    TITLE_TEXT: "ITERATIVE SHOOTER GAME",

    // Help Screen text
    HELP_TITLE: "HOW TO PLAY" ,
    HELP_LINES: [
        "MOVE WITH W A S D",
        "AIM WITH MOUSE",
        "CLICK TO SHOOT", 
    ],
};